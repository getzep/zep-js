export interface IZepClient {
   baseURL: string;

   headers: any;
}
