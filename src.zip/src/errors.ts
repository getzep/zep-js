/**
 * Represents an error received from the API.
 */
class APIError {
   code: number;

   message: string;

   /**
    * Constructs a new APIError instance.
    * @param {number} code - The error code.
    * @param {string} message - The error message.
    */
   constructor(code: number, message: string) {
      this.code = code;
      this.message = message;
   }
}

// eslint-disable-next-line import/prefer-default-export
export { APIError };
